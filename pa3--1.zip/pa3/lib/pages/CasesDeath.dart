import 'package:flutter/material.dart';
import 'package:pa3/pages/LoginComplete.dart';
import 'package:pa3/pages/StartLive.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

// Future<List<Casedata>> fetchCasedata(http.Client client) async{
//   String url = 'https://covid.ourworldindata.org/data/owid-covid-data.json';
//   final response = await http.get(Uri.parse('https://covid.ourworldindata.org/data/owid-covid-data.json'));
//   //print(response.body);
//   return compute(parseCasedata, response.body);
// }

// List<Casedata> parseCasedata(String responseBody){
//   final parsed = jsonDecode(responseBody).cast<Map<String, dynamic>>();
//
//   return parsed.map<Casedata>((json)=>Casedata.fromJson(json)).toList();
// }
// class Casedata{
//   final String country;
//   final String iso_code;
//   final dynamic data;
//
//   Casedata({
//     @required this.country, @required this.iso_code, @required this.data});
//   factory Casedata.fromJson(Map<String, dynamic>json){
//     return Casedata(
//       country: json['country'] as String,
//       iso_code: json['iso_code'] as String,
//       data: json['data'] as dynamic,
//     );
//   }
// }

class CasesDeath extends StatelessWidget {
  TextEditingController usrid;
  final String page = "Cases/Death Page";
  String graph = "graph";
  String table = "table";

  CasesDeath({Key key, @required this.usrid}):super(key:key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 350,
              height: 110,
              decoration: BoxDecoration(
              shape:BoxShape.rectangle,
              borderRadius:BorderRadius.circular(10.0),
              border: Border.all(
                color:Colors.black38,
                width:3
            ),
            ),
              child:Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                      width: 350,
                      height: 110,
                      decoration: BoxDecoration(
                        shape:BoxShape.rectangle,
                        borderRadius:BorderRadius.circular(10.0),
                        border: Border.all(
                            color:Colors.black38,
                            width:3
                        ),
                      ),
                      // child:
                      // FutureBuilder<List<Casedata>>(
                      //   future:fetchCasedata(http.Client()),
                      //   builder:(context, snapshot){
                      //     if(snapshot.hasError) print(snapshot.error);
                      //     return snapshot.hasData
                      //         ? Center(child:CasedataList(casedata : snapshot.data))
                      //         :Center(child:CircularProgressIndicator());
                      //   },
                      // )
                  ),
                ],
              )
            ),
            Container(
                margin: EdgeInsets.only(top:15.0) ,
              width: 350,
              height: 250,
              decoration: BoxDecoration(
                shape:BoxShape.rectangle,
                borderRadius:BorderRadius.circular(10.0),
                border: Border.all(
                    color:Colors.black38,
                    width:3
                ),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      GestureDetector(
                        child: Container(
                          alignment: Alignment.center,
                          // width: 60.0,
                          height: 35.0,
                          child: Text("Graph1",
                            style: TextStyle(color:Colors.blue, fontWeight: FontWeight.bold),),
                        ),
                        onTap: (){
                          graph = "graph1";
                          (context as Element).markNeedsBuild();
                        },
                      ),
                      GestureDetector(
                        child: Container(
                          alignment: Alignment.center,
                          height: 35.0,
                          child: Text("Graph2",
                            style: TextStyle(color:Colors.blue, fontWeight: FontWeight.bold),),
                        ),
                        onTap: (){
                          graph = "graph2";
                          (context as Element).markNeedsBuild();
                        },
                      ),
                      GestureDetector(
                        child: Container(
                          alignment: Alignment.center,
                          height: 35.0,
                          child: Text("Graph3",
                            style: TextStyle(color:Colors.blue, fontWeight: FontWeight.bold),),
                        ),
                        onTap: (){
                          graph = "graph3";
                          (context as Element).markNeedsBuild();
                        },
                      ),
                      GestureDetector(
                        child: Container(
                          alignment: Alignment.center,
                          height: 35.0,
                          child: Text("Graph4",
                            style: TextStyle(color:Colors.blue, fontWeight: FontWeight.bold),),
                        ),
                        onTap: (){
                          graph = "graph4";
                          (context as Element).markNeedsBuild();
                        },
                      ),
                    ],
                  ),
                  Divider(
                    color:Colors.grey,
                    thickness: 3,
                  ),
                  Container(
                    child: Text(graph),
                  )

                ],
              )
            ),
            Container(
                margin: EdgeInsets.only(top:15.0) ,
              width: 350,
              height: 220,
              decoration: BoxDecoration(
                shape:BoxShape.rectangle,
                borderRadius:BorderRadius.circular(10.0),
                border: Border.all(
                    color:Colors.black38,
                    width:3
                ),
              ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        GestureDetector(
                          child: Container(
                            alignment: Alignment.center,
                            width: 75.0,
                            height: 35.0,
                            child: Text("Table1",
                              style: TextStyle(color:Colors.blue, fontWeight: FontWeight.bold),),
                          ),
                          onTap: (){
                            table = "TABLE1";
                            (context as Element).markNeedsBuild();
                          },
                        ),
                        GestureDetector(
                          child: Container(
                            alignment: Alignment.center,
                            width: 75.0,
                            height: 30.0,
                            child: Text("Table2",
                              style: TextStyle(color:Colors.blue, fontWeight: FontWeight.bold),),
                          ),
                          onTap: (){
                            table = "TABLE2";
                            (context as Element).markNeedsBuild();
                          },
                        ),
                      ],
                    ),
                    Divider(
                      color:Colors.grey,
                      thickness: 3,
                    ),
                    Container(
                      child: Text(table),
                    )
                  ],
                )
            ),
          ],
        )
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder:(context)=>StartLive(usrid: usrid,page: page,)),
          );
        },
        child:Icon(Icons.list),
    ),
    );
  }
}
// class CasedataList extends StatelessWidget{
//   final List<Casedata> casedata;
//
//   CasedataList({Key key, this.casedata}):super(key: key);
//
//   int find_korea(){
//     int korea_index;
//     for(int i=0;i<country.length;i++){
//       if(casedata[i].country == 'South Korea'){
//         korea_index = i;
//         break;
//       }
//     }
//     return korea_index;
//   }
//
//   @override
//   Widget build(BuildContext context){
//     return GridView.count(
//         padding: EdgeInsets.all(5.0),
//         crossAxisCount: 2,
//         childAspectRatio: 8/1,
//         children: [
//           Text("Total Vacc."),
//           Text("Parsed latest date",
//             textAlign: TextAlign.right,),
//          // Text(totalVacc().toString()+" people"),
//           // Text(country[find_korea()].data[1]['total_vaccinations'].toString()+" people"),
//        //   Text(casedata[find_korea()].data[country[find_korea()].data.length-1]['date'].toString(),
//        //     textAlign: TextAlign.right,),
//           Text("Total fully Vacc."),
//           Text("Daily Vacc.",
//         //    textAlign: TextAlign.right,),
//         //  Text(totalFullyVacc().toString()+" people"),
//         //  Text(dailyVacc().toString()+" people",
//         //    textAlign: TextAlign.right,),
//         ]
//     );
//
//   }
// }